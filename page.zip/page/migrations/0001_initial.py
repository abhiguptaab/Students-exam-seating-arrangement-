# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Block',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('BlockNo', models.IntegerField()),
            ],
        ),
        migrations.CreateModel(
            name='college',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
            ],
        ),
        migrations.CreateModel(
            name='Department',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('DeptName', models.CharField(max_length=40)),
                ('FloorNo', models.IntegerField()),
            ],
        ),
        migrations.CreateModel(
            name='Hall_Arggengment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('Class', models.CharField(max_length=40)),
                ('StartNo', models.IntegerField(max_length=40)),
                ('NoOfBench', models.IntegerField(max_length=40)),
                ('EndNo', models.IntegerField(max_length=40)),
                ('SeatNo', models.IntegerField(max_length=40)),
            ],
        ),
        migrations.CreateModel(
            name='Student',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('SEATNO', models.IntegerField(max_length=40)),
                ('CLASS', models.CharField(max_length=40)),
                ('PRN', models.CharField(max_length=40)),
                ('NAME', models.CharField(max_length=40)),
                ('CONTACT', models.CharField(max_length=40)),
                ('EMAIL', models.CharField(max_length=40)),
                ('ADDRESS', models.CharField(max_length=40)),
                ('STUDDEPT', models.CharField(max_length=40)),
            ],
        ),
        migrations.CreateModel(
            name='StudSit',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('NoOfStud', models.CharField(max_length=40)),
                ('Class', models.CharField(max_length=40)),
                ('SeatNo', models.IntegerField(max_length=40)),
                ('BenchNo', models.IntegerField(max_length=40)),
                ('Floor', models.CharField(max_length=40)),
                ('Dep', models.CharField(max_length=40)),
                ('BlockNo', models.IntegerField(max_length=40)),
            ],
        ),
        migrations.AddField(
            model_name='block',
            name='FloorNo',
            field=models.ForeignKey(to='page.Department'),
        ),
    ]
