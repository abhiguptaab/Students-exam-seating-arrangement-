# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('page', '0002_delete_hall_arggengment'),
    ]

    operations = [
        migrations.CreateModel(
            name='Hall_Arggengment',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('BlockNo', models.IntegerField(max_length=40)),
                ('Class', models.CharField(max_length=40)),
                ('StartNo', models.IntegerField(max_length=40)),
                ('NoOfBench', models.IntegerField(max_length=40)),
                ('EndNo', models.IntegerField(max_length=40)),
                ('Status', models.IntegerField(max_length=40)),
                ('SeatNo', models.IntegerField(max_length=40)),
            ],
        ),
    ]
