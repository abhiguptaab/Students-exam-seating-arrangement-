from django.contrib import admin
from . models import Student, Hall_Arggengment,  Department, Block, StudSit
# Register your models here.

admin.site.register(Student)
admin.site.register(Hall_Arggengment)
admin.site.register(StudSit)
admin.site.register(Department)
admin.site.register(Block)