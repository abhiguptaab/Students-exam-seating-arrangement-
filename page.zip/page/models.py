from django.contrib.auth.models import Permission, User
from django.db import models

#file = request.FILES['fileUpload']
#data = [row for row in csv.reader(file.read().splitlines())]

class Student(models.Model):

    SEATNO = models.IntegerField(max_length=40)
    CLASS = models.CharField(max_length=40)
    PRN = models.CharField(max_length=40)
    NAME = models.CharField(max_length=40)
    CONTACT = models.CharField(max_length=40)
    EMAIL = models.CharField(max_length=40)
    ADDRESS = models.CharField(max_length=40)
    STUDDEPT = models.CharField(max_length=40)

    def __str__(self):
        return(str(self.SEATNO) + '----' + self.PRN + '----' + self.NAME)

class college(models.Model):
    username1 = "sandip"
    password1 = "123"


class Hall_Arggengment(models.Model):
    #user = models.ForeignKey(User, default=1, on_delete = models.CASCADE)
    BlockNo = models.IntegerField(max_length=40)
    Class = models.CharField(max_length=40)
    StartNo = models.IntegerField(max_length=40)
    NoOfBench = models.IntegerField(max_length=40)
    EndNo = models.IntegerField(max_length=40)

    #NoOfStud = models.IntegerField(max_length=40)
    #Department = models.CharField(max_length=40)
    SeatNo = models.IntegerField(max_length=40)
    #Floor = models.CharField(max_length=40)
    #SEATNO = models.ForeignKey(Student, on_delete=models.CASCADE)


class StudSit(models.Model):
    Class = models.CharField(max_length=40)
    StartNo = models.IntegerField(max_length=40)
    EndNo = models.IntegerField(max_length=40)
    SeatNo = models.IntegerField(max_length=40)
    BenchNo = models.IntegerField(max_length=40)
    Floor = models.CharField(max_length=40)
    Dep = models.CharField(max_length=40)
    BlockNo = models.IntegerField(max_length=40)
    STUDDEP = models.CharField(max_length=40)

class Department(models.Model):
    DeptName = models.CharField(max_length=40)
    FloorNo = models.IntegerField(max_length=40)

    def __str__(self):
        return (self.DeptName + '----' + str(self.FloorNo))


class Block(models.Model):
    FloorNo = models.ForeignKey(Department, on_delete=models.CASCADE)
    BlockNo = models.IntegerField(max_length=40)
    Status = models.CharField(max_length=40)
    def __str__(self):
        return (str(self. FloorNo) + '----' + str(self.BlockNo))

