from django.contrib.auth import authenticate, login
from django.contrib.auth import logout
from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from . models import Student, Department, StudSit, Block,college
from django.views.generic import View
from .forms import UserForm, StudentForm
import csv

def Index(request):
    if not request.user.is_authenticated():
        return render(request, 'page/homepage.html')
    else:
        return render(request, 'page/homepage.html')


def index(request):
    studsit = StudSit.objects.all()
    student = Student.objects.all()
    context = {
        'student': student,
        'studsit': studsit,
    }
    query1 = request.GET.get("q1")
    query = request.GET.get("q")
    if query:
        student = student.filter(
            Q(SEATNO__icontains=query)
        ).distinct()

        for stud in student:
            for sit in studsit:
                if query1 == "S" and sit.SeatNo == stud.SEATNO:
                    seatno = stud.SEATNO
                    benchno = sit.BenchNo
                    floor = sit.Floor
                    dept = sit.Dep
                    blockno = sit.BlockNo
                    return render(request, 'page/Index6.html',
                                  {'seatno': seatno, 'benchno': benchno, 'floor': floor, 'dept': dept,
                                   'blockno': blockno})
                elif query1 == "T" and sit.SeatNo == stud.SEATNO:
                    seatno = stud.SEATNO
                    benchno = sit.BenchNo
                    floor = sit.Floor
                    dept = sit.Dep
                    blockno = sit.BlockNo
                    return render(request, 'page/Index6.html',{'seatno': seatno, 'benchno': benchno, 'floor': floor, 'dept': dept,
                                   'blockno': blockno})
                elif query1 == "F" and sit.SeatNo == stud.SEATNO:
                    seatno = stud.SEATNO
                    benchno = sit.BenchNo
                    floor = sit.Floor
                    dept = sit.Dep
                    blockno = sit.BlockNo
                    return render(request, 'page/Index6.html', {'seatno': seatno, 'benchno': benchno, 'floor': floor, 'dept': dept,
                                   'blockno': blockno})
                elif query1 == "B" and sit.SeatNo == stud.SEATNO:
                    seatno = stud.SEATNO
                    benchno = sit.BenchNo
                    floor = sit.Floor
                    dept = sit.Dep
                    blockno = sit.BlockNo
                    return render(request, 'page/Index6.html', {'seatno': seatno, 'benchno': benchno, 'floor': floor, 'dept': dept,
                                   'blockno': blockno})
        return render(request, 'page/failed_to_search.html')
    else:
        return render(request, 'page/failed_to_search' , context)



def logout_user(request):
    logout(request)
    form = UserForm(request.POST or None)
    context = {
        "form": form,
    }
    return render(request, 'page/login.html', context)


def login_user(request):
    if request.method == "POST":
        all_students = Student.objects.all()
        context = {
            'all_students': all_students,
        }

        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                #albums = Album.objects.filter(user=request.user)
                return render(request, 'page/search_seat.html',context)
            else:
                return render(request, 'page/login.html', {'error_message': 'Your account has been disabled'})
        else:
            return render(request, 'page/login.html', {'error_message': 'Invalid login'})
    return render(request, 'page/login.html')



def staff_login(request):
    if request.method == "POST":
        all_students = Student.objects.all()
        context = {
            'all_students': all_students,
        }

        username = request.POST['username']
        password = request.POST['password']
        #user = authenticate(username=username, password=password)
        if college.username1==username and college.password1==password:
            #if user.is_active:
            #login(request, user)
                #albums = Album.objects.filter(user=request.user)
            return render(request, 'page/Allocation.html',context)
        else:
            return render(request, 'page/login_staff.html', {'error_message': 'Invalid login'})
    return render(request, 'page/login_staff.html')




def register(request):
    form = UserForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        username = form.cleaned_data['username']
        password = form.cleaned_data['password']
        user.set_password(password)
        user.save()
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                all_students = Student.objects.all()
                return render(request, 'page/index.html', {'all_students': all_students})
    context = {
        "form": form,
    }
    return render(request, 'page/register.html', context)


def upload_csv(request):
        data = {}
        if "GET" == request.method:
            return render(request, "page/csv.html", data)
        # if not GET, then proceed
        try:
            # form = StaffForm(request.POST or None, request.FILES or None)
            #print("11111111111111111111111111111111111111111111111")
            #csv_file = request.FILES["csv_file"]
            #print(csv_file)
            with open(r'C:\Users\Lenovo\Desktop\C.csv') as csvfile:
                 print("sssssssssssssssssssssssssssssssssssssssssssssssssssss")
                 reader = csv.DictReader(csvfile)
                 for row in reader:
                    # The header row values become your keys
                    CLASS=row['CLASS']
                    SEATNO= row['SEATNO']
                    PRN= row['PRN']
                    NAME = row['NAME']
                    CONTACT= row['CONTACT']
                    EMAIL= row['EMAIL']
                    ADDRESS= row['ADDRESS']
                    STUDDEPT= row['STUDDEPT']
                    new_Student = Student(CLASS=CLASS,SEATNO=SEATNO,PRN=PRN,NAME=NAME, CONTACT=CONTACT,EMAIL=EMAIL,ADDRESS=ADDRESS,STUDDEPT=STUDDEPT)
                    new_Student.save()
                    print(new_Student)
        except Exception as e:
            print("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
        #context={
            #'name': new_Staff
       # }
        return render(request, "page/faltu.html",data)
def hall(request):
    if not request.user.is_authenticated:
        return render(request, 'page/login_staff.html')

    else:
        return render(request, 'page/indertdeptname.html')

def hall1(request):
    department = Department.objects.all()
    Dept = request.GET.get("q1")
    print("in hall1111111111111111111111111111")
    floor = request.GET.get("q2")
    for dept in department:
        DEPT = dept.DeptName
        FLOOR = dept.FloorNo
        if  Dept == dept.DeptName and floor == str(FLOOR):
                print("in hall1")
                p = dept.pk
                context = {
                    'p' : p,
                }
                return render(request, 'page/check_hall.html', context)
    return render(request, 'page/check_hall.html')


def hall2(request, p):
    D = Department.objects.get(pk=p)
    all_blocks = D.block_set.all()
    context = {
        'all_blocks' : all_blocks,
        'D' : 'D',
        'p' : p,
    }
    return render(request, 'page/check_hall1.html', context)

def allocate_seat(request, blockno, p):

    department = Department.objects.get(pk=p)
    #floor = Department.objects.get(pk=p),
    context = {
        'blockno' : blockno,
        'p' : p,
        'department' : department
    }
    return render(request, 'page/addseatno.html',context)

def hallarrengment(request):
    flag = 0
    flag1 = 0
    startn = request.GET.get("q1")
    endn = request.GET.get("q2")
    startno = int(startn)
    endno = int(endn)
    blockno = request.GET.get("q3")
    deptname = request.GET.get("q4")
    floor = request.GET.get("q5")
    clss = request.GET.get("cll")
    blockn = int(blockno)
    student = Student.objects.all()
    for stud in student:
        if stud.SEATNO == startno:
            flag = 1

    if flag == 0:
        context = {
            'msg': 'Ending exam Number Is Invalid',
            'deptname': deptname,
            'floor': floor,
            'blockn': blockn
        }
        return render(request, 'page/addseatno1.html', context)

    for stud in student:
        if stud.SEATNO == endno:
            flag1 = 1

    if flag1 == 0:
        context = {
            'msg': 'Ending exam Number Is Invalid',
            'deptname': deptname,
            'floor': floor,
            'blockn': blockn
        }
        return render(request, 'page/addseatno1.html', context)


    studentsit = StudSit.objects.all()
    for sit in studentsit:
        for seatno in range(startno, endno + 1):
            if sit.SeatNo == seatno:
                context = {
                    'msg': 'Something is wrong ,'
                           'you may add seat number which is arrenged before,'
                           'Enter Appropriate No',
                    'deptname': deptname,
                    'floor': floor,
                    'blockn': blockn
                }
                return render(request, 'page/addseatno1.html', context)

    count = 0
    NoOfStud = endno - startno
    stud = StudSit.objects.all()
    for st in stud:
        if st.BlockNo == blockn:
            count = count + 1

    if NoOfStud >= 30:
        context = {
            'msg' : 'Maximum 30 Students are Allowed',
            'deptname' : deptname,
            'floor' : floor,
            'blockn' : blockn
        }
        return render(request, 'page/addseatno1.html', context)

    elif count >= 30:
        blockstatus = Block.objects.get(BlockNo=blockn)
        blockstatus.Status = "Full"
        blockstatus.save()

        context = {
            'msg': 'The Block Is already Filled With maximum 30 Students ',
            'deptname': deptname,
            'floor': floor,
            'blockn': blockn,
            'count' : count,

        }
        return render(request, 'page/fullhall1.html', context)

    bench = count
    #startno = startno + count
    #endno = endno - count
    for seatno in range(startno, endno+1):
        student = Student.objects.get(SEATNO=seatno)
        studsit = StudSit()
        bench = bench + 1
        studsit.SeatNo = seatno
        studsit.Class = clss
        studsit.STUDDEP = student.STUDDEPT
        studsit.Dep = deptname
        studsit.BlockNo = blockn
        studsit.StartNo = startno
        studsit.EndNo = endno
        studsit.Floor = floor
        studsit.BenchNo = bench
        studsit.save()
        blockstatus = Block.objects.get(BlockNo=blockn)
        if bench == 30:
            rem = 30 - count
            blockstatus.Status = "Full"
            blockstatus.save()
        if bench > 30:
            context = {
                'msg': 'Maximum 30 Students are Allowed '
                       'Hall Is Already full',
                'deptname': deptname,
                'floor': floor,
                'blockn': blockn,
                'count': count,
                'rem' : rem,
            }
            return render(request, 'page/fullhall.html', context)
    return render(request, 'page/reg.html')



def Delete(request):
    return render(request, 'page/read_deletestudent.html')


def Delete1(request):
    query = request.GET.get("q1")
    if query:
        student = Student.objects.all()
        for stud in student:
            if query == stud.PRN:
                stud.delete()
                return render(request, 'page/errormsg.html', {'msg': 'deleted'})
        return render(request, 'page/errormsg.html', {'msg': 'hutiyapa ho gaya'})
    return render(request, 'page/errormsg.html', {'msg': 'not deleted'})



def check(request):
    studsit = StudSit.objects.all()
    context = {
        'studsit': studsit
    }
    return render(request, 'page/check1.html', context)


def success(request):
    return render(request, 'page/success.html')

def checkhllstatus(request):
    return render(request, 'page/enter_deptname.html')

def checkhllstatus1(request):
    department = Department.objects.all()
    Dept = request.GET.get("q1")
    floor = request.GET.get("q2")
    for dept in department:
        DEPT = dept.DeptName
        FLOOR = dept.FloorNo
        if  Dept == dept.DeptName and floor == str(FLOOR):
                p = dept.pk
                context = {
                    'p' : p,
                }
                return render(request, 'page/gethall.html', context)
    return render(request, 'page/gethall.html')


def checkhall(request, p):
    D = Department.objects.get(pk=p)
    all_blocks = D.block_set.all()
    context = {
        'all_blocks' : all_blocks,
        'D' : 'D',
        'p' : p,
    }
    return render(request, 'page/gethall1.html', context)

def getcheckhall(request, blockno, p):
    department = Department.objects.get(pk=p)
    studsit = StudSit.objects.all()
    #floor = Department.objects.get(pk=p),
    blc = int(blockno)
    context = {
        'blc' : blc,
        'p' : p,
        'department' : department,
        'studsit' : studsit
    }
    return render(request, 'page/finalcheck.html',context)


def hall3(request, blockno, p):
    department = Department.objects.get(pk=p)

    #floor = Department.objects.get(pk=p),
    context = {
        'blockno' : blockno,
        'p' : p,
        'department' : department
    }
    return render(request, 'page/addseatno.html',context)


def checkallhall(request):
    blocks = Block.objects.all()
    studsit = StudSit.objects.all()
    context = {
        'blocks' : blocks,
        'studsit' : studsit
    }
    return render(request, 'page/displayblocks.html' , context)



def checkhalldet(request, blockno):
    blockn = int(blockno)
    blocks = Block.objects.all()
    studsit = StudSit.objects.all()
    context = {

        'blc' : blockn,
        'studsit' : studsit,
    }
    return render(request, 'page/finalcheck.html' , context)


def clearhall(request, blockno):
    blockn = int(blockno)
    studsit = StudSit.objects.all()
    for stud in studsit:
        if stud.BlockNo == blockn:
            blockstatus = Block.objects.get(BlockNo=blockno)
            blockstatus.Status = "Empty"
            blockstatus.save()
            stud.delete()
    return render(request, 'page/finalcheck.html' )

def viewstudent(request):
    return render(request, 'page/viewstudent.html' )


def firstyear(request):
    student = Student.objects.all()
    return render(request, 'page/first.html', { 'student' : student , 'F' : 'F'})

def secondyear(request):
    student = Student.objects.all()
    return render(request, 'page/second.html', { 'student' : student , 'S' : 'S'})

def thirdyear(request):
    student = Student.objects.all()
    return render(request, 'page/third.html', { 'student' : student , 'T' : 'T'})

def lastyear(request):
    student = Student.objects.all()
    return render(request, 'page/last.html', { 'student' : student , 'B' : 'B'})


def deleteone(request, blockno):
    studsit = StudSit.objects.all()
    blockn = int(blockno)
    context = {
        'studsit' : studsit,
        'blockn' : blockn,
    }
    return render(request, 'page/deleteone.html',context)


def deleteone1(request, blockno, seatno):
    studsit = StudSit.objects.all()
    blockn = int(blockno)
    seatn = int(seatno)
    for sit in studsit:
        if sit.BlockNo == blockn and sit.SeatNo == seatn:
            blockstatus = Block.objects.get(BlockNo=blockn)
            studentsit = StudSit.objects.get(SeatNo= seatn)
            studentsit.delete()
            blockstatus.Status = "Empty"
            blockstatus.save()
            #studentsit.save()
    return render(request, 'page/detail.html', {'blc' : blockn})


def deptwise(request):
    Class = request.GET.get("Clss")
    department = request.GET.get("dept")
    studsit = StudSit.objects.all()
    context = {
        'clss' : Class,
        'department' : department,
        'studsit' : studsit,
    }
    return render(request, 'page/detail.html', context)

def staffsearchseat(request):
    return render(request, 'page/search_seat.html')
